import React, { useState, useEffect, createContext } from "react";
import firebase from "../firebase";
export let AudioContextApi = createContext();

let AudioContextProvider = ({ children }) => {
  let [state, setState] = useState([]);
  useEffect(() => {
    let fetchAudios = async () => {
      // fetch data from database
      let audioList = firebase.database().ref("audio_library");
      // firebase event to fetch
      audioList.on("value", callback => {
        let SpotifyMusics = [];
        callback.forEach(audio => {
          let {
            DownloadMp3,
            DownloadPoster,
            audio_artist,
            audio_category,
            audio_details,
            audio_language,
            audio_title,
          } = audio.val();

          SpotifyMusics.push({
            id: audio.key,
            title: audio_title,
            artist: audio_artist,
            category: audio_category,
            details: audio_details,
            language: audio_language,
            poster: DownloadPoster,
            src: DownloadMp3,
          });
        });
        setState(SpotifyMusics);
      });
    };
    fetchAudios();
  }, []);
  return (
    <AudioContextApi.Provider value={state}>
      {children}
    </AudioContextApi.Provider>
  );
};
export default AudioContextProvider;
