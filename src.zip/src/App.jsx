import React, { useContext, Fragment } from "react";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import Navbar from "./Pages/HeaderComponent/Navbar";
import Home from "./Pages/Home";
import Login from "./Components/AuthComponent/Login";
import Signup from "./Components/AuthComponent/Signup";
import PageNotFound from "./Pages/PageNotFound";
import { AuthContextApi } from "./Apis/AuthContext";
import UserHome from "./UsersComponents/UserHome";

const App = () => {
  let state = useContext(AuthContextApi);
  let IsAnonymousUserTemplate = () => {
    return (
      <section id="SpotifyMainBlock">
        <article>
          <Router>
            <header>
              <Navbar />
            </header>
            <ToastContainer />
            <main>
              {/* dynamic routing starts here */}
              <Switch>
                <Route path="/" exact>
                  <Home />
                </Route>
                <Route path="/login" exact>
                  <Login />
                </Route>
                <Route path="/signup" exact>
                  <Signup />
                </Route>
                <Route path="*">
                  <PageNotFound />
                </Route>
              </Switch>
              {/* Dynamic routing ends here */}
            </main>
          </Router>
        </article>
      </section>
    );
  };
  let IsAuthenticatedTemplate = () => {
    return <UserHome />;
  };
  return (
    <Fragment>
      {state === null ? (
        <IsAnonymousUserTemplate />
      ) : (
        <IsAuthenticatedTemplate />
      )}
    </Fragment>
  );
};

export default App;
