import React from "react";

const UserRightBlock = () => {
  return <div className="userRightBlock">UserRightBlock</div>;
};

export default UserRightBlock;
