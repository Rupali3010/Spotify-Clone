import React, { useContext, useReducer, useRef, useState } from "react";
import { AudioContextApi } from "../../Apis/AudioContext";
import Spinner from "../../Pages/Spinner/Spinner";

const MusicHome = () => {
  let AUDIO = useContext(AudioContextApi);
  let [play, setPlay] = useState(false);
  let audioRef = useRef(false);

  return (
    <section id="musicHome">
      <article>
        {AUDIO === null ? (
          <Spinner />
        ) : (
          AUDIO.map(audio => {
            let {
              id,
              title,
              artist,
              language,
              details,
              category,
              poster,
              src,
            } = audio;
            return (
              <div className="col-3" key={id}>
                <figure>
                  <img src={poster} alt={title} />
                  <h2>{title}</h2>
                  <audio src={src} ref={audioRef} controls></audio>
                </figure>
              </div>
            );
          })
        )}
      </article>
    </section>
  );
};

export default MusicHome;
