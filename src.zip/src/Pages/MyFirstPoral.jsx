// import React from "react";
// import ReactDOM from "react-dom";

// const MyFirstPoral = () => {
//   return ReactDOM.createPortal(
//     <div>
//       <h1>My First Portal</h1>
//       <p>Outside DOM tree</p>
//     </div>,
//     document.getElementById("root1")
//   );
// };

// export default MyFirstPoral;
