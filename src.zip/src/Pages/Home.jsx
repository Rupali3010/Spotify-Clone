import React from "react";
import Slider from "./SliderComponent/Slider";

const Home = () => {
  return (
    <div>
      <Slider />
    </div>
  );
};

export default Home;
