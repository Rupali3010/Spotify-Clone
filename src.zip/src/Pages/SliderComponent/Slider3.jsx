import React from 'react'

const Slider3 = () => {
    return (
        <div>
            
        </div>
    )
}

export default Slider3
